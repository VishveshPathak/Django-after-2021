from django.urls import path
from . import views
urlpatterns=[
    path('login/',views.login,name='login'),
    path('showuserdata/', views.ShowUserDetails,name='showdata'),
    path('register/', views.register,name='register'),
    path('logout/',views.Logout,name='logout'),
    path('transfer/',views.transfer,name='transfer'),
    path('editProfile/',views.ChangeProfileData,name='edit profile'),
    path('transferWallet/',views.transferWallet, name='transferWallet'),
    path('cardDetails/',views.cardDetails,name='cardDetails'),
    path('paywithcard/',views.paywithcard,name='paywithcard'),
    path('netbankingdetails/',views.netbankingdetails,name='netbankingdetails'),
    path('paywithnetbanking',views.paywithnetbanking,name='paywithnetbanking'),
    path('forgotPassword/',views.forgotPassword,name='forgotPassword'),
    path('coupon/',views.coupon,name='coupon'),
    path('sendotp/',views.sendotp,name='sendotp'),
    path('kyc/',views.kyc,name='kyc')
]