from django.http.response import HttpResponse
from django.shortcuts import render,redirect
from django.contrib import auth
from django.contrib.auth.models import User
from .models import ExtendedUser
from django.contrib.auth.decorators import login_required
from django.contrib.auth import logout
from .helpers import send_otp
import random

A=['co8yhde','breal','weqew','sada','idias','dpwqpe']
# Create your views here.
def home(request):
    try:
        eu=ExtendedUser.objects.filter(user=request.user)
        return render(request,'home.html',{'data':eu,'kyc_pending':eu.kyc})
    except:
        pass
    return render(request,'home.html')
def login(request):
    if request.method=="POST":
        user=auth.authenticate(username=request.POST['uname'],password=request.POST['pw'])
        user=User.objects.get(username=request.POST['uname'])
        eu=ExtendedUser.objects.get(user=user)
        if user is not None:
            auth.login(request, user)
            return redirect('http://localhost:8000',{'data':eu})
        else:
            return render(request,'login.html',{'error':'wrong credentials. please check your details'})
    return render(request,'login.html',{})

def register(request):
    if request.method=="POST":
        if request.POST['password1']==request.POST['password2']:
            try:
                user=User.objects.get(username=request.POST['uname'])
                return render(request,'register.html',{'error':'Username already taken'})
            except User.DoesNotExist:
                user=User.objects.create_user(username=request.POST['uname'],password=request.POST['password1'])
                phone=request.POST['phone']
                age=request.POST['age']
                balance=50
                email=request.POST['email']
                user.email=email
                user.save()
                city=request.POST['city']
                isDigit=False
                for i in city:
                    k=ord(i)-ord('0')
                    if k>=0 and k<10:
                        print(k)
                        isDigit=True
                if phone[0]==0 or isDigit==True or int(age)>100 or len(phone)!=10:
                    return render(request,'register.html',{'error':'please enter city without numbers, phone not starting with 0 or age less than 100'})
                else:
                    newExtendedUser=ExtendedUser(phone=phone,age=age,balance=balance,city=city,user=user,adhaar=0,cvv=0,cardnumber=0,netbankingID=0,netbankingPW='')
                    newExtendedUser.adhaar=0
                    newExtendedUser.save()
                    auth.login(request,user)
                    return render(request,'success.html',{'success':"user successfully created"})
        else:
            return render(request,'register.html',{'error':'passwords dont match'})
    return render(request,'register.html',{})

@login_required(login_url='http://localhost:8000/accounts/login')
def ShowUserDetails(request):
    data=ExtendedUser.objects.filter(user=request.user)
    return render(request,'showdata.html',{'data':data})

def Logout(request):
    logout(request)
    return redirect('http://localhost:8000',{'msg':'You have logged out successfully!'})

@login_required(login_url='http://localhost:8000/accounts/login')
def transfer(request):
    if request.method=="POST":
        un=request.POST['uname']
        amt=request.POST['amt']
        data=ExtendedUser.objects.filter(user=request.user)
        table=ExtendedUser.objects.get(user=request.user)
        if int(table.balance)<=int(amt) and int(amt)>0:
            table.balance=int(table.balance)-int(amt)
            table.save()
        
        user1=User.objects.get(username=un)
        data1=ExtendedUser.objects.filter(user=user1)
        table2=ExtendedUser.objects.get(user=user1)
        if int(amt)>0:
            table2.balance=int(table2.balance)+int(amt)
            table2.save()
        
        return render(request,'transfer.html',{'data':data})
    data=ExtendedUser.objects.filter(user=request.user)
    return render(request,'transfer.html',{'data':data})

@login_required(login_url='http://localhost:8000/accounts/login')
def ChangeProfileData(request):
    table1=ExtendedUser.objects.get(user=request.user)
    if request.method=="POST":
        try:
            phone1=request.POST['phone']
            age1=request.POST['age']
            city1=request.POST['city']
            table1.phone=phone1
            table1.kyc=False
            table1.age=age1
            table1.city=city1
            table1.save()
        except:
            return redirect('http://localhost:8000/accounts/editProfile',{'balance':table1.balance,'phone':table1.phone,'age':table1.age,'city':table1.city})
        return render(request,'Success.html')
    else:
        return render(request,'editProfile.html',{'balance':table1.balance,'phone':table1.phone,'age':table1.age,'city':table1.city})

@login_required(login_url='http://localhost:8000/accounts/login')
def transferWallet(request):
    table=ExtendedUser.objects.filter(user=request.user)
    data=ExtendedUser.objects.get(user=request.user)
    if request.method=="POST":
        
        try:
            x=request.POST['Payment Method']
            y=request.POST['newmethod']
        except:
            y=0
        if y!=0:
            y=1
        if x == 'card':
            if data.cardnumber==0 or y==1:
                return redirect('http://localhost:8000/accounts/cardDetails',{'pmt':x})
            else:
                t=random.randint(1000,9999)
                data.adhaar=t
                data.save()
                send_otp(request.user.email,t)
                return redirect('http://localhost:8000/accounts/paywithcard')
        elif x=='netbanking':
            if data.netbankingID==0 or y==1:
                return redirect('http://localhost:8000/accounts/netbankingdetails',{'pmt':x})
            else:
                t=random.randint(1000,9999)
                data.adhaar=t
                data.save()
                send_otp(request.user.email,t)
                return redirect('http://localhost:8000/accounts/paywithnetbanking')

    else:
        return render(request,'transfertowallet.html',{'data':table})

def cardDetails(request):
    if request.method=="POST":
            cardnumber=request.POST['cardnumber']
            cvv=request.POST['cvv']
            expdate=request.POST['expirydate']
            table=ExtendedUser.objects.get(user=request.user)
            table.cardnumber=cardnumber
            table.cvv=cvv
            table.cardexpiry=expdate
            table.save()
            return HttpResponse('successfully added card <br> <a href="http://localhost:8000/accounts/transferWallet"> click here to proceed with payment</a>')
    else:
        x='card'
        return render(request,'cardDetails.html',{'pmt':x})

def paywithcard(request):
    if request.method=="POST":
        table=ExtendedUser.objects.get(user=request.user)
        cash=request.POST['cash']
        cardnumber=request.POST['cardnumber']
        cvv=request.POST['cvv']
        expdate=request.POST['expirydate']
        otp=request.POST['otp']

        if int(table.cardnumber)!=int(cardnumber) or int(table.cvv)!=int(cvv):
            return HttpResponse('payment failed exit the browser and restart <br> <a href="http://localhost:8000/accounts/transferWallet">retry?</a>')
        if int(table.adhaar)==int(otp):
            table.balance=int(table.balance)+int(cash)
            table.save()
            return HttpResponse('funds transferred <br> <a href="http://localhost:8000/accounts/transferWallet">click here to visit wallet</a>')
        else:
            return HttpResponse('wrong otp try again')
    else:
        return render(request,'paywithcard.html')

def netbankingdetails(request):
    if request.method=="POST":
        id=request.POST['netbankingID']
        pw=request.POST['netbankingPW']
        table=ExtendedUser.objects.get(user=request.user)
        table.netbankingID=id
        table.netbankingPW=pw
        table.save()
        return HttpResponse('successfully added netbanking details <br> <a href="http://localhost:8000/accounts/transferWallet"> click here to proceed with payment</a>')
    else:
        x='netbanking'
        return render(request,'netbankingdetails.html',{'pmt':x})

def paywithnetbanking(request):
    if request.method=="POST":
        id=request.POST['netbankingID']
        pw=request.POST['netbankingPW']
        cash=request.POST['cash']
        table=ExtendedUser.objects.get(user=request.user)
        if table.netbankingPW!=pw or int(table.netbankingID)!=int(id):
            return HttpResponse('payment failed close browser and restart <br> <a href="http://localhost:8000/accounts/transferWallet">retry?</a>')
        otp=request.POST['otp']
        if int(table.adhaar)==int(otp):
            table.balance=int(table.balance)+int(cash)
            table.save()
            return HttpResponse('funds transferred <br> <a href="http://localhost:8000/accounts/transferWallet">click here to visit wallet</a>')
        else:
            return HttpResponse('wrong otp try again')
    else:
        return render(request,'paywithnetbanking.html')

def forgotPassword(request):
    if request.method=="POST":
        u=User.objects.get(username=request.POST['uname'])
        eu=ExtendedUser.objects.get(user=u)
        otp=request.POST['otp']
        if int(eu.adhaar)==int(otp):
            u.set_password(request.POST['password1'])
            u.save()
            return HttpResponse('password changed')
        else:
            return render(request,'forgotpassword.html',{'error':'wrong otp'})
    else:
        return render(request,'forgotpassword.html')

def coupon(request):
    if request.method=="POST":
        A.remove(A[0])
        return HttpResponse('coupon code is \'asxsaxsa\'')
    else:
        return render(request,'coupon.html',{'code':['10','24','32','45'],'reward':A})

def sendotp(request):
    if request.method=="POST":
        un=request.POST['uname']
        em=request.POST['email']
        x=User.objects.get(username=un)
        y=ExtendedUser.objects.get(user=x)
        email=x.email
        t=random.randint(1000,9999)
        y.adhaar=t
        y.save()
        if x:
            send_otp(email,t)
            return HttpResponse('otp has been send <a href="http://localhost:8000/accounts/forgotPassword">reset password here</a>')
        else:
            return HttpResponse('Not found')
    else:
        return render(request,'sendotp.html')

def kyc(request):
    if request.method=="POST":
        eu=ExtendedUser.objects.get(user=request.user)
        return render(request,'kyc.html')
    else:
        return render(request,'kyc.html',{'url1':'http://localhost:8000/templates/silhoutte.jpg','url2':'http://localhost:8000/templates/silhoutte.jpg'})